<?php
	$_SESSION=$_GET["fil"];
?>
<iframe src=listquali.php height="200" width="=200"></iframe>