<?php
$dt=mktime(0,0,0,3,1,2008);
echo date("Y-m-d",$dt);
?>