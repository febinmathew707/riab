<?php 
 session_start();
$_SESSION['page']="kerala";
//Header("Location: monitoring/first.php");
Header("Location: first.php");
?>

