<?php session_start(); 
$_SESSION["page"]="kerala";
?>

 
 &nbsp;
 <center>
  <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
     <td width="80%" align="center"  valign=top height=100>
   <br><br><br><br>
 <table border="0" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="70%" id="AutoNumber1" height="171">
  <tr>
     <td width="100%" align="right"  background="images/logintop.jpg" height="29"></td>
   </tr>
	 <tr>
     <td width="100%" align="center"   height="39" valign="top">
     	<table border="1" cellspacing="0" style="border-collapse: collapse" 
		 bordercolor="#E2E0E0" width="100%" id="AutoNumber1" bgcolor="#FFFFFF" cellpadding="4">
	 <tr >
     <td width="51%" align="right" height="23" class="txtright">
     <font color="#000000"><b>LoginId</b></font></td>
     <td width="2%" height="23">:</td>
     <td width="47%" height="23" >
    
       <input type="text" name="txtuid" size="35" id="txtuid" class=txtbox>
     </td>
   </tr>
   <tr>
     <td width="51%" align="right" height="23" class="txtright">
     <font color="#000000"><b>Password</b></font></td>
     <td width="2%" height="23">:</td>
     <td width="47%" height="23">
    
       <input type="password" name="txtpwd" id="txtpwd" size="35" class="txtbox">
&nbsp;</td>
   </tr>
   <tr>
     <td width="51%" align="center" colspan=3 height="34" class="txtright">     
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	 </td>
   </tr>
   
   <tr>
     <td width="51%" height="27" class="txtright">&nbsp;</td>
     <td width="2%" height="27"></td>
     <td width="47%" height="27"><input type="button" value="Login" onclick="log1()">&nbsp;
     <input type="reset" value="Cancel" onclick="cancel()">
	 </td>
   </tr>
   </table>
     </td>
     
  

   
   <div id="result"></div>
   <div id="w"></div>
 </table>
 </td>
 <td width="20%" align="right"  valign=top height=100>
 <!--
 <table border="0" cellpadding="0" cellspacing="0" width="80%" height="94">
          
          
          <tbody><tr>
            <td scope="row" height="46"><div align="center"><img src="soemoniter.php_files/blue-dot.jpg" width="4" height="4"></div></td>
            <td class="rightmenu" scope="row" height="46">&nbsp;<a href="http://www.invismultimedia.com/riab/live-feed.php"><font face="Verdana" size="2"><b>Live Feed</b></font></a></td>
          </tr>
          <tr>
            <td scope="row" height="46"><div align="center"><img src="soemoniter.php_files/blue-dot.jpg" width="4" height="4"></div></td>
            <td class="rightmenu" scope="row" height="46">&nbsp;<a href="http://www.invismultimedia.com/riab/riab-intranet.php"><font face="Verdana" size="2"><b>RIAB Intranet</b></font></a></td>
          </tr>
          <tr>
            <td scope="row" height="2"><div align="center"><img src="soemoniter.php_files/blue-dot.jpg" width="4" height="4"></div></td>
            <td class="rightmenu" scope="row" height="46">&nbsp;<a href="http://www.invismultimedia.com/riab/psu-intranet.php"><font face="Verdana" size="2"><b>PSU Intranet</b></font></a></td>
          </tr>
          <!--<tr>
            <td scope="row"><div align="center"><img src="images/blue-dot.jpg" width="4" height="4" /></div></td>
            <td height="27" class="rightmenu" scope="row"><a href="contact-us.php">Contact</a></td>
          </tr>
          
        </tbody></table>   -->
        </td></tr></table>
 </center>
<br><br><br><br><br><br><br>
 