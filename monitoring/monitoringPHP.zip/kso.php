<img src="images/riab.gif">
<iframe height='500px' width='100%' name='zoho-Daily_KPI_Report_KSO_Form' frameborder='0' allowTransparency='true' scrolling='auto' src='http://creator.zoho.com/riabgok/daily-kpi-report-kso/form-embed/Daily_KPI_Report_KSO_Form/'></iframe>
