<?php session_start();
	$_SESSION["page"]="liststream";
?>
<div align=right></div><br>
<table width="92%" border=0 cellpadding=0 cellspacing=0><tr>
<td width="100%" valign="top" background="images/streamtop.gif" height="25"></td></tr>
<tr>
<td width="100%" valign="top" background="images/streammiddle.gif"  align=center> <b><font face="Verdana" size="3" color="red">Work Sites Gallery</font></b>
</td>
</tr>
<tr>
<td width="100%" valign="top" background="images/streammiddle.gif" >
<table width="96%" border=0 cellpadding=0 cellspacing=0><tr>
<td width="50%" valign="top" align=center ><a href="JavaScript:disp('stream')"> <img src="images/kso.gif"> </a></td>
<td width="50%" valign="top" align=center ><a href="JavaScript:disp('malabarstream')"><img src="images/malabar.gif"></a></td>
</tr></table>
</td></tr><tr>
<td width="100%" valign="top" background="images/streambottom.gif" height="25"></td></tr>
</table>
