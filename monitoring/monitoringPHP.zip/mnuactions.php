	<body bgcolor=white>
	<div style="border-style: solid; border-width: 0;border-color: #9F9F9F; background-color: #F5F3F3; height:20" 
	align="left"
	onmouseover="JavaScript:this.style.backgroundColor='#CBCCCA'"
	onmouseout="JavaScript:this.style.backgroundColor='#F5F3F3'" >
    <font face="Verdana" size="2">
    <a href="JavaScript:dispmain('createcomaccount')">&nbsp;&nbsp; Create Company Accounts</a></font></div>    
    
    <div style="border-style: solid; border-width: 0;border-color: #9F9F9F; background-color: #F5F3F3; height:20" 
	align=left
	onmouseover="JavaScript:this.style.backgroundColor='#CBCCCA'"
	onmouseout="JavaScript:this.style.backgroundColor='#F5F3F3'" 
	>
    <font face="Verdana" size="2">
    <a href="JavaScript:dispmain('listcomaccounts')">&nbsp;&nbsp; List Created Accounts</font></div> 
    
    <div style="border-style: solid; border-width: 0;border-color: #9F9F9F; background-color: #F5F3F3; height:20" 
	align=left
	onmouseover="JavaScript:this.style.backgroundColor='#CBCCCA'"
	onmouseout="JavaScript:this.style.backgroundColor='#F5F3F3'" 
	>
    <font face="Verdana" size="2">
    <!--
    <a href="JavaScript:dispmain('listemployees')">&nbsp;&nbsp; List Featured Employees</font></div> 
    <div style="border-style: solid; border-width: 0;border-color: #9F9F9F; background-color: #F5F3F3; height:20" 
	align=left
	onmouseover="JavaScript:this.style.backgroundColor='#CBCCCA'"
	onmouseout="JavaScript:this.style.backgroundColor='#F5F3F3'" 
	> -->
    <font face="Verdana" size="2">
    <a href="JavaScript:disp1('sendcompassword')">&nbsp;&nbsp; Send Company Password</font></div>
    
    <div style="border-style: solid; border-width: 0;border-color: #9F9F9F; background-color: #F5F3F3; height:20" 
	align=left
	onmouseover="JavaScript:this.style.backgroundColor='#CBCCCA'"
	onmouseout="JavaScript:this.style.backgroundColor='#F5F3F3'" 
	>
    <font face="Verdana" size="2">
    <a href="JavaScript:dispmain('createbill')">&nbsp;&nbsp; Send Monthly Bill</a></font></div>
    
    <div style="border-style: solid; border-width: 0;border-color: #9F9F9F; background-color: #F5F3F3; height:20" 
	align=left
	onmouseover="JavaScript:this.style.backgroundColor='#CBCCCA'"
	onmouseout="JavaScript:this.style.backgroundColor='#F5F3F3'" 
	>
    <font face="Verdana" size="2">
    <a href="logout.php">&nbsp;&nbsp; LogOut</font></div> 
    </body>