<?php
$handle = printer_open();
printer_start_doc($handle, "My Document");
printer_start_page($handle);
printer_write($handle, "Text to print");
printer_end_page($handle);
printer_end_doc($handle);
printer_close($handle);
?>
