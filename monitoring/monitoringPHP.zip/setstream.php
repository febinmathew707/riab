<?php session_start();
	$_SESSION["page"]="liststream";
?>